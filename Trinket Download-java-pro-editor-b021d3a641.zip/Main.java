public class Main {
    public static void main(String[] args) {
        Person p = new Person("Хүслэн", 18);
        p.greet();
    }
}